package br.com.ebac.ebacdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbacDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
