package br.com.ebac.ebacdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbacDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbacDemoApplication.class, args);
	}

}
